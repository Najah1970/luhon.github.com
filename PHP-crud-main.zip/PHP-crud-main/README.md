# PHP basic crud (create read update delete) using myql
PHP insert data
PHP display data
PHP create record
php edit or update record
php delete record
